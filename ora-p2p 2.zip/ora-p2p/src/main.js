// src/main.js — rôle initiateur/récepteur, lien d’invitation + QR, code-ami, chat
import { deriveKeyFromPassword } from './lib/authService.js';
import { getKdf, saveKdf } from './lib/kdfStore.js';
import { PGPService } from './lib/pgpService.js';
import { WebRTCDirectService } from './lib/webrtcDirectService.js';
import { publicKeyToFriendCode } from './lib/friendCode.js';

const $ = (id) => document.getElementById(id);
const log = (...a) => console.log('[ORA]', ...a);

function setStatus(t) { const el = $('initStatus'); if (el) el.textContent = t; }

function addMessage(text, author = 'peer') {
  const host = $('chat'); if (!host) return;
  const li = document.createElement('li');
  li.className = author === 'me' ? 'me' : 'peer';
  li.textContent = (author === 'me' ? 'Moi: ' : 'Lui/Elle: ') + text;
  host.appendChild(li);
  li.scrollIntoView({ behavior: 'smooth', block: 'end' });
}

// Affiche le code-ami dans #friendCode (et fallback #myFriendCode), supporte <span>/<input>
function setFriendCode(code) {
  const els = [ $('friendCode'), $('myFriendCode') ].filter(Boolean);
  for (const el of els) {
    if ('value' in el) el.value = code || '—';
    else el.textContent = code || '—';
    el.setAttribute('title', code || '');
  }
}

// base64url helpers
function toB64Url(u8) {
  const CHUNK = 0x8000; let s = '';
  for (let i = 0; i < u8.length; i += CHUNK) s += String.fromCharCode.apply(null, u8.subarray(i, i + CHUNK));
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/,'');
}
function fromB64Url(s) {
  s = s.replace(/-/g,'+').replace(/_/g,'/'); while (s.length % 4) s += '=';
  const bin = atob(s); const u8 = new Uint8Array(bin.length);
  for (let i=0;i<bin.length;i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

// ---------- Invitation (création + parsing) ----------
async function createInvitation() {
  if (!window._myPublicArmored) throw new Error('Clé publique locale absente. Initialisez d’abord vos clés.');
  // Force initiateur (corrige “non-initiator”)
  await WebRTCDirectService.beginInitiator();
  const offerB64 = await WebRTCDirectService.createOffer();

  const fc = window._myFriendCode || await publicKeyToFriendCode(window._myPublicArmored);
  const payload = { v: 1, offerB64, pub: window._myPublicArmored, fc };
  const b64url = toB64Url(new TextEncoder().encode(JSON.stringify(payload)));
  const uri = `${location.origin}${location.pathname}#i=${b64url}`;

  if ($('inviteLink')) $('inviteLink').value = uri;
  if ($('inviteHref')) { $('inviteHref').href = uri; $('inviteHref').textContent = 'Lien d’invitation'; }
  if ($('offerOut')) $('offerOut').value = offerB64;

  // QR (si la lib qrcode est installée)
  try {
    const mod = await import(/* @vite-ignore */ 'qrcode');
    const canvas = $('qr') || $('inviteQr') || $('inviteQR');
    if (canvas && mod?.default?.toCanvas) await mod.default.toCanvas(canvas, uri, { errorCorrectionLevel: 'M' });
  } catch { /* lib optionnelle non installée, pas grave */ }

  log('Invitation prête');
  return { uri, offerB64 };
}

function parseInvitationFromHash() {
  const m = location.hash.match(/[#&]i=([A-Za-z0-9\-_]+)/);
  if (!m) return null;
  const payload = JSON.parse(new TextDecoder().decode(fromB64Url(m[1]))); // {v, offerB64, pub, fc}

  // On devient le récepteur (B) sur une session neuve
  WebRTCDirectService.beginReceiver();

  if ($('offerIn') && payload.offerB64) $('offerIn').value = payload.offerB64;
  if (payload.pub) window._recipientPub = payload.pub;
  if ($('senderFriendCode') && payload.fc) $('senderFriendCode').textContent = payload.fc;

  // Empêche de régénérer une invitation en mode B
  $('regenInvite')?.setAttribute('disabled', 'true');

  log('Invitation détectée — rôle RECEVEUR (B). Cliquez “Générer l’answer”.');
  return payload;
}

// ---------- Init PGP (persistance du sel PBKDF2) ----------
async function initWithPassword(password) {
  try {
    if (!password || !password.trim()) password = $('passwordInput')?.value || '';
    if (!password || !password.trim()) { alert('Saisissez un mot de passe.'); return; }

    setStatus('⏳ Initialisation…');

    let kdf = await getKdf();
    let derived;
    if (kdf?.saltBase64) {
      derived = await deriveKeyFromPassword(password, kdf.saltBase64, kdf.iterations || 200000);
    } else {
      derived = await deriveKeyFromPassword(password, null, 200000);
      await saveKdf({ saltBase64: derived.saltBase64, iterations: 200000 });
    }

    const { publicKeyArmored } = await PGPService.initOrRestore(derived.key);
    window._myPublicArmored = publicKeyArmored;

    const fc = await publicKeyToFriendCode(publicKeyArmored);
    window._myFriendCode = fc;
    setFriendCode(fc);

    setStatus('✅ Clés prêtes');
    log('Init OK — friendCode:', fc);
  } catch (e) {
    console.error(e);
    setStatus('❌ ' + (e.message || e));
    alert('Initialisation impossible: ' + (e.message || e));
  }
}

// ---------- WebRTC (auto-échange de clé + chat) ----------
function wireWebRTC() {
  WebRTCDirectService.on('__dc-open', async () => {
    try { if (window._myPublicArmored) await WebRTCDirectService.send('kx/pgp', { pub: window._myPublicArmored }); }
    catch (e) { console.error('Envoi pub à __dc-open échoué:', e); }
  });

  let echoed = false;
  WebRTCDirectService.on('kx/pgp', async ({ pub }) => {
    try {
      window._recipientPub = pub;
      if (!echoed && window._myPublicArmored) {
        echoed = true;
        await WebRTCDirectService.send('kx/pgp', { pub: window._myPublicArmored });
      }
    } catch (e) { console.error('kx/pgp handler:', e); }
  });

  WebRTCDirectService.on('ora-chat', async (encryptedArmored) => {
    try {
      const plain = await PGPService.decrypt(encryptedArmored, window._privateArmored);
      addMessage(plain, 'peer');
    } catch (e) { console.error('Déchiffrement message:', e); }
  });
}

// ---------- Handlers UI ----------
async function onCreateOffer() {
  try {
    await WebRTCDirectService.beginInitiator();
    const offerB64 = await WebRTCDirectService.createOffer();
    if ($('offerOut')) $('offerOut').value = offerB64;
    alert('Offre générée.');
  } catch (e) { console.error(e); alert('Échec création offre: ' + (e.message || e)); }
}

async function onHandleOffer() {
  try {
    const val = $('offerIn')?.value?.trim();
    if (!val) return alert('Collez une offer.');
    await WebRTCDirectService.beginReceiver();
    const ans = await WebRTCDirectService.handleOffer(val);
    if ($('answerOut')) $('answerOut').value = ans;
    alert('Answer générée.');
  } catch (e) { console.error(e); alert('Échec traitement offer: ' + (e.message || e)); }
}

async function onApplyAnswer() {
  try {
    const val = $('answerIn')?.value?.trim();
    if (!val) return alert('Collez une answer.');
    const r = WebRTCDirectService.getRole();
    if (r !== 'A') return alert('Vous n’êtes pas initiateur (A). Générez une invitation d’abord.');
    await WebRTCDirectService.applyAnswer(val);
    alert('Connexion appliquée.');
  } catch (e) { console.error(e); alert('Échec application answer: ' + (e.message || e)); }
}

async function onSendMessage(e) {
  e?.preventDefault?.();
  try {
    const input = $('msgInput'); if (!input) return;
    const msg = input.value.trim(); if (!msg) return;
    if (!window._recipientPub) return alert('Pas de clé publique du correspondant.');
    const encrypted = await PGPService.encryptFor(msg, window._recipientPub);
    await WebRTCDirectService.send('ora-chat', encrypted);
    addMessage(msg, 'me');
    input.value = '';
  } catch (e) { console.error(e); alert('Envoi impossible: ' + (e.message || e)); }
}

async function onRegenInvite() {
  try { await createInvitation(); alert('Invitation prête.'); }
  catch (e) { console.error(e); alert('Impossible de créer l’invitation: ' + (e.message || e)); }
}

async function onCopyInviteLink() {
  const val = $('inviteLink')?.value || $('inviteHref')?.href;
  if (!val) return alert('Aucun lien à copier.');
  try { await navigator.clipboard.writeText(val); alert('Lien copié ✅'); }
  catch { alert('Copie impossible.'); }
}

async function onCopyFriendCode() {
  const val = window._myFriendCode;
  if (!val) return alert('Aucun code-ami à copier.');
  try { await navigator.clipboard.writeText(val); alert('Code-ami copié ✅'); }
  catch { alert('Copie impossible.'); }
}

// ---------- Boot ----------
function wireUI() {
  $('btnInit')?.addEventListener('click', (e) => { e.preventDefault(); initWithPassword(); });
  $('passwordInput')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); initWithPassword(e.currentTarget.value || ''); }
  });

  $('regenInvite')?.addEventListener('click', onRegenInvite);
  $('copyInviteLink')?.addEventListener('click', onCopyInviteLink);
  $('copyFriendCode')?.addEventListener('click', onCopyFriendCode);

  $('handleOfferBtn')?.addEventListener('click', onHandleOffer);
  $('applyAnswerBtn')?.addEventListener('click', onApplyAnswer);

  $('sendForm')?.addEventListener('submit', onSendMessage);
}

function main() {
  setStatus('🟡 JS chargé — cliquez “Créer / Restaurer mes clés”.');
  wireUI();
  wireWebRTC();
  parseInvitationFromHash(); // si on a ouvert un lien d’invitation
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', main);
} else {
  main();
}

// Exports optionnels
export { createInvitation, parseInvitationFromHash, initWithPassword };
