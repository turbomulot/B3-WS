# Ora P2P — Démo complète (serverless)

## Prérequis
- Node 18+
- Navigateur moderne (WebRTC + WebCrypto)

## Installation
```bash
npm install
npm run dev
